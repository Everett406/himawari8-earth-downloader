# 🛰️ Himawari8 Earth Downloader

🌍 全自动Himawari8地球图片下载器 + 视频合成器

## 🚀 快速开始

1. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

2. **启动下载调度器**
   ```bash
   # Windows
   双击 start_scheduler.bat
   
   # 命令行
   python himawari8_scheduler.py
   ```

3. **制作延时视频**
   ```bash
   # Windows
   双击 start_video_composer.bat
   
   # 命令行
   python video_composer.py
   ```

## 📁 项目结构

```
himawari8-earth-downloader/
├── 🛰️ himawari8_scheduler.py      # 智能调度器
├── 📥 himawari8downloader.py      # 基础下载器
├── 🎬 video_composer.py           # 视频合成器
├── ⚙️ requirements.txt            # Python依赖
├── 📊 scheduler_config.json       # 调度器配置
├── 🎥 video_config.json          # 合成器配置
├── 🚀 start_scheduler.bat         # Windows启动脚本
├── 🎬 start_video_composer.bat    # Windows合成器脚本
├── 📖 README.md                   # 项目文档
└── 📋 其他文档文件...
```

## ✨ 功能特色

- **🔄 智能调度**：每10分钟自动下载最新地球图片
- **🎬 视频合成**：将图片合成为流畅的延时视频
- **⏰ 时间选择**：支持精确的时间范围选择
- **📊 双模式**：单帧时长和帧率模式可选
- **🌐 Web接口**：预留API接口供前端集成

## 📄 许可证

MIT License - 详见 LICENSE 文件

## 👨‍💻 作者

Himawari8 Earth Downloader 项目团队

---

**🌟 项目已完整测试，支持一键启动运行！**
